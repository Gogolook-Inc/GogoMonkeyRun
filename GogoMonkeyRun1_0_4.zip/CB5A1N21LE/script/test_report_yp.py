
import sys,traceback
from com.android.monkeyrunner import MonkeyRunner, MonkeyDevice, MonkeyImage

def getDevice():
	return sys.argv[1]

def getPath():
	return sys.argv[2]

def startSteps():
	print ("start monkey runner.")

	# test_report_yp.mr

	# add START FROM DESKTOP at the 'first' line of code

	# to start app from desktop.

	# add END BACK TO DESKTOP at the 'last' line of code.

	# to end app back to desktop.
	print("START FROM DESKTOP")
	device.shell('am force-stop gogolook.callgogolook2')
	MonkeyRunner.sleep(4.0)

	print("TOUCH|{'x':80,'y':880,'type':'downAndUp',}")
	device.touch(80,880,MonkeyDevice.DOWN_AND_UP)
	MonkeyRunner.sleep(4.0)

	print("TOUCH|{'x':77,'y':445,'type':'downAndUp',}")
	device.touch(77,445,MonkeyDevice.DOWN_AND_UP)
	MonkeyRunner.sleep(4.0)

	print("TOUCH|{'x':61,'y':770,'type':'downAndUp',}")
	device.touch(61,770,MonkeyDevice.DOWN_AND_UP)
	MonkeyRunner.sleep(4.0)

	print("TOUCH|{'x':61,'y':1152,'type':'downAndUp',}")
	device.touch(61,1152,MonkeyDevice.DOWN_AND_UP)
	MonkeyRunner.sleep(4.0)

	print("TAKE SNAPSHOT")
	result = device.takeSnapshot()
	print("Writes the screenshot to a file")
	result.writeToFile(dir_picture+'/screenshot_'+str(0)+'_0.png','png')

	print("DRAG|{'start':(322,952),'end':(328,154),'duration':0.3,'steps':1,}")
	start = (322,952)
	end = (328,154)
	device.drag(start,end,0.3,1)
	MonkeyRunner.sleep(4.0)

	print("TOUCH|{'x':362,'y':1005,'type':'downAndUp',}")
	device.touch(362,1005,MonkeyDevice.DOWN_AND_UP)
	MonkeyRunner.sleep(4.0)

	print("TAKE SNAPSHOT")
	result = device.takeSnapshot()
	print("Writes the screenshot to a file")
	result.writeToFile(dir_picture+'/screenshot_'+str(0)+'_1.png','png')

	print("TOUCH|{'x':261,'y':928,'type':'downAndUp',}")
	device.touch(261,928,MonkeyDevice.DOWN_AND_UP)
	MonkeyRunner.sleep(4.0)

	print("TAKE SNAPSHOT")
	result = device.takeSnapshot()
	print("Writes the screenshot to a file")
	result.writeToFile(dir_picture+'/screenshot_'+str(0)+'_2.png','png')

	print("TOUCH|{'x':493,'y':1120,'type':'downAndUp',}")
	device.touch(493,1120,MonkeyDevice.DOWN_AND_UP)
	MonkeyRunner.sleep(4.0)

	print("TAKE SNAPSHOT")
	result = device.takeSnapshot()
	print("Writes the screenshot to a file")
	result.writeToFile(dir_picture+'/screenshot_'+str(0)+'_3.png','png')

	print("TOUCH|{'x':530,'y':1144,'type':'downAndUp',}")
	device.touch(530,1144,MonkeyDevice.DOWN_AND_UP)
	MonkeyRunner.sleep(4.0)

	print("WAIT|{'seconds':5.0,}")
	MonkeyRunner.sleep(5.0)
	print("PRESS|{'name':'BACK','type':'downAndUp',}")
	device.press('KEYCODE_BACK',MonkeyDevice.DOWN_AND_UP)
	MonkeyRunner.sleep(4.0)

	print("TOUCH|{'x':88,'y':456,'type':'downAndUp',}")
	device.touch(88,456,MonkeyDevice.DOWN_AND_UP)
	MonkeyRunner.sleep(4.0)

	print("TOUCH|{'x':101,'y':778,'type':'downAndUp',}")
	device.touch(101,778,MonkeyDevice.DOWN_AND_UP)
	MonkeyRunner.sleep(4.0)

	print("TOUCH|{'x':32,'y':962,'type':'downAndUp',}")
	device.touch(32,962,MonkeyDevice.DOWN_AND_UP)
	MonkeyRunner.sleep(4.0)

	print("DRAG|{'start':(666,642),'end':(661,298),'duration':0.3,'steps':1,}")
	start = (666,642)
	end = (661,298)
	device.drag(start,end,0.3,1)
	MonkeyRunner.sleep(4.0)

	print("TOUCH|{'x':114,'y':845,'type':'downAndUp',}")
	device.touch(114,845,MonkeyDevice.DOWN_AND_UP)
	MonkeyRunner.sleep(4.0)

	print("TOUCH|{'x':66,'y':1136,'type':'downAndUp',}")
	device.touch(66,1136,MonkeyDevice.DOWN_AND_UP)
	MonkeyRunner.sleep(4.0)

	print("TAKE SNAPSHOT")
	result = device.takeSnapshot()
	print("Writes the screenshot to a file")
	result.writeToFile(dir_picture+'/screenshot_'+str(0)+'_4.png','png')

	print("DRAG|{'start':(378,952),'end':(400,232),'duration':0.3,'steps':1,}")
	start = (378,952)
	end = (400,232)
	device.drag(start,end,0.3,1)
	MonkeyRunner.sleep(4.0)

	print("TOUCH|{'x':352,'y':1000,'type':'downAndUp',}")
	device.touch(352,1000,MonkeyDevice.DOWN_AND_UP)
	MonkeyRunner.sleep(4.0)

	print("TAKE SNAPSHOT")
	result = device.takeSnapshot()
	print("Writes the screenshot to a file")
	result.writeToFile(dir_picture+'/screenshot_'+str(0)+'_5.png','png')

	print("TOUCH|{'x':370,'y':936,'type':'downAndUp',}")
	device.touch(370,936,MonkeyDevice.DOWN_AND_UP)
	MonkeyRunner.sleep(4.0)

	print("TAKE SNAPSHOT")
	result = device.takeSnapshot()
	print("Writes the screenshot to a file")
	result.writeToFile(dir_picture+'/screenshot_'+str(0)+'_6.png','png')

	print("TOUCH|{'x':149,'y':546,'type':'downAndUp',}")
	device.touch(149,546,MonkeyDevice.DOWN_AND_UP)
	MonkeyRunner.sleep(4.0)

	print("TAKE SNAPSHOT")
	result = device.takeSnapshot()
	print("Writes the screenshot to a file")
	result.writeToFile(dir_picture+'/screenshot_'+str(0)+'_7.png','png')

	print("TOUCH|{'x':509,'y':1093,'type':'downAndUp',}")
	device.touch(509,1093,MonkeyDevice.DOWN_AND_UP)
	MonkeyRunner.sleep(4.0)

	print("TAKE SNAPSHOT")
	result = device.takeSnapshot()
	print("Writes the screenshot to a file")
	result.writeToFile(dir_picture+'/screenshot_'+str(0)+'_8.png','png')

	print("TOUCH|{'x':533,'y':1149,'type':'downAndUp',}")
	device.touch(533,1149,MonkeyDevice.DOWN_AND_UP)
	MonkeyRunner.sleep(4.0)

	print("WAIT|{'seconds':5.0,}")
	MonkeyRunner.sleep(5.0)
	print("PRESS|{'name':'BACK','type':'downAndUp',}")
	device.press('KEYCODE_BACK',MonkeyDevice.DOWN_AND_UP)
	MonkeyRunner.sleep(4.0)

	print("PRESS|{'name':'BACK','type':'downAndUp',}")
	device.press('KEYCODE_BACK',MonkeyDevice.DOWN_AND_UP)
	MonkeyRunner.sleep(4.0)

	print("END BACK TO DESKTOP")
	device.shell('am force-stop gogolook.callgogolook2')
	MonkeyRunner.sleep(4.0)

	print("end monkey runner.")

print("get device name")
device_name = getDevice()

print("get dir of screenshot")
dir_picture = getPath()

print("Connects to the current device, returning a MonkeyDevice object")
device = MonkeyRunner.waitForConnection(5,device_name)

if not device:
	print("device connect...fail")
	sys.exit(1)
else:
	deviceModel = device.getProperty('build.model')
	print("device connect...success")
	startSteps()
	if not deviceModel in ['HTC One_M8','HTC Desire 700 dual sim']:
		device.shell("stop")
	sys.exit(0)

