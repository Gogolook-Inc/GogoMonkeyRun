
import sys,traceback
from com.android.monkeyrunner import MonkeyRunner, MonkeyDevice, MonkeyImage

def getDevice():
	return sys.argv[1]

def getPath():
	return sys.argv[2]

def startSteps():
	print ("start monkey runner.")

	# testSpam.mr

	# add START FROM DESKTOP at the 'first' line of code

	# to start app from desktop.

	# add END BACK TO DESKTOP at the 'last' line of code.

	# to end app back to desktop.
	print("START FROM DESKTOP")
	device.shell('am force-stop gogolook.callgogolook2')
	MonkeyRunner.sleep(4.0)

	print("TOUCH|{'x':117,'y':888,'type':'downAndUp',}")
	device.touch(117,888,MonkeyDevice.DOWN_AND_UP)
	MonkeyRunner.sleep(4.0)

	print("TOUCH|{'x':29,'y':522,'type':'downAndUp',}")
	device.touch(29,522,MonkeyDevice.DOWN_AND_UP)
	MonkeyRunner.sleep(4.0)

	print("DRAG|{'start':(522,744),'end':(517,413),'duration':0.3,'steps':1,}")
	start = (522,744)
	end = (517,413)
	device.drag(start,end,0.3,1)
	MonkeyRunner.sleep(4.0)

	print("DRAG|{'start':(538,749),'end':(536,424),'duration':0.3,'steps':1,}")
	start = (538,749)
	end = (536,424)
	device.drag(start,end,0.3,1)
	MonkeyRunner.sleep(4.0)

	print("DRAG|{'start':(549,658),'end':(549,357),'duration':0.3,'steps':1,}")
	start = (549,658)
	end = (549,357)
	device.drag(start,end,0.3,1)
	MonkeyRunner.sleep(4.0)

	print("TOUCH|{'x':114,'y':845,'type':'downAndUp',}")
	device.touch(114,845,MonkeyDevice.DOWN_AND_UP)
	MonkeyRunner.sleep(4.0)

	print("TOUCH|{'x':50,'y':1125,'type':'downAndUp',}")
	device.touch(50,1125,MonkeyDevice.DOWN_AND_UP)
	MonkeyRunner.sleep(4.0)

	print("TOUCH|{'x':656,'y':752,'type':'downAndUp',}")
	device.touch(656,752,MonkeyDevice.DOWN_AND_UP)
	MonkeyRunner.sleep(4.0)

	print("TOUCH|{'x':656,'y':752,'type':'downAndUp',}")
	device.touch(656,752,MonkeyDevice.DOWN_AND_UP)
	MonkeyRunner.sleep(4.0)

	print("TOUCH|{'x':360,'y':738,'type':'downAndUp',}")
	device.touch(360,738,MonkeyDevice.DOWN_AND_UP)
	MonkeyRunner.sleep(4.0)

	print("TOUCH|{'x':360,'y':1114,'type':'downAndUp',}")
	device.touch(360,1114,MonkeyDevice.DOWN_AND_UP)
	MonkeyRunner.sleep(4.0)

	print("TOUCH|{'x':48,'y':533,'type':'downAndUp',}")
	device.touch(48,533,MonkeyDevice.DOWN_AND_UP)
	MonkeyRunner.sleep(4.0)

	print("WAIT|{'seconds':3.0,}")
	MonkeyRunner.sleep(3.0)
	print("TAKE SNAPSHOT")
	result = device.takeSnapshot()
	print("Writes the screenshot to a file")
	result.writeToFile(dir_picture+'/screenshot_'+str(0)+'_0.png','png')

	print("TOUCH|{'x':160,'y':1240,'type':'downAndUp',}")
	device.touch(160,1240,MonkeyDevice.DOWN_AND_UP)
	MonkeyRunner.sleep(4.0)

	print("TOUCH|{'x':184,'y':522,'type':'downAndUp',}")
	device.touch(184,522,MonkeyDevice.DOWN_AND_UP)
	MonkeyRunner.sleep(4.0)

	print("TOUCH|{'x':64,'y':1144,'type':'downAndUp',}")
	device.touch(64,1144,MonkeyDevice.DOWN_AND_UP)
	MonkeyRunner.sleep(4.0)

	print("WAIT|{'seconds':3.0,}")
	MonkeyRunner.sleep(3.0)
	print("TAKE SNAPSHOT")
	result = device.takeSnapshot()
	print("Writes the screenshot to a file")
	result.writeToFile(dir_picture+'/screenshot_'+str(0)+'_1.png','png')

	print("TOUCH|{'x':160,'y':1256,'type':'downAndUp',}")
	device.touch(160,1256,MonkeyDevice.DOWN_AND_UP)
	MonkeyRunner.sleep(4.0)

	print("TOUCH|{'x':160,'y':1256,'type':'downAndUp',}")
	device.touch(160,1256,MonkeyDevice.DOWN_AND_UP)
	MonkeyRunner.sleep(4.0)

	print("END BACK TO DESKTOP")
	device.shell('am force-stop gogolook.callgogolook2')
	MonkeyRunner.sleep(4.0)

	print("end monkey runner.")

print("get device name")
device_name = getDevice()

print("get dir of screenshot")
dir_picture = getPath()

print("Connects to the current device, returning a MonkeyDevice object")
device = MonkeyRunner.waitForConnection(5,device_name)

if not device:
	print("device connect...fail")
	sys.exit(1)
else:
	deviceModel = device.getProperty('build.model')
	print("device connect...success")
	startSteps()
	if not deviceModel in ['HTC One_M8','HTC Desire 700 dual sim']:
		device.shell("stop")
	sys.exit(0)

