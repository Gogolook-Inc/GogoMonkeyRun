
import sys,traceback
from com.android.monkeyrunner import MonkeyRunner, MonkeyDevice, MonkeyImage

def getDevice():
	return sys.argv[1]

def getPath():
	return sys.argv[2]

def startSteps():
	print ("start monkey runner.")

	# testNDP.mr

	# add START FROM DESKTOP at the 'first' line of code

	# to start app from desktop.

	# add END BACK TO DESKTOP at the 'last' line of code.

	# to end app back to desktop.
	print("START FROM DESKTOP")
	device.shell('am force-stop gogolook.callgogolook2')
	MonkeyRunner.sleep(4.0)

	print("LOOP(2)")
	for index in range(2):
		print("TOUCH|{'x':106,'y':864,'type':'downAndUp',}")
		device.touch(106,864,MonkeyDevice.DOWN_AND_UP)
		MonkeyRunner.sleep(4.0)

		print("TOUCH|{'x':632,'y':202,'type':'downAndUp',}")
		device.touch(632,202,MonkeyDevice.DOWN_AND_UP)
		MonkeyRunner.sleep(4.0)

		print("TOUCH|{'x':133,'y':890,'type':'downAndUp',}")
		device.touch(133,890,MonkeyDevice.DOWN_AND_UP)
		MonkeyRunner.sleep(4.0)

		print("TOUCH|{'x':48,'y':1130,'type':'downAndUp',}")
		device.touch(48,1130,MonkeyDevice.DOWN_AND_UP)
		MonkeyRunner.sleep(4.0)

		print("WAIT|{'seconds':5.0,}")
		MonkeyRunner.sleep(5.0)
		print("TAKE SNAPSHOT")
		result = device.takeSnapshot()
		print("Writes the screenshot to a file")
		result.writeToFile(dir_picture+'/screenshot_'+str(index)+'_0.png','png')

		print("TOUCH|{'x':176,'y':1234,'type':'downAndUp',}")
		device.touch(176,1234,MonkeyDevice.DOWN_AND_UP)
		MonkeyRunner.sleep(4.0)

		print("TOUCH|{'x':658,'y':176,'type':'downAndUp',}")
		device.touch(658,176,MonkeyDevice.DOWN_AND_UP)
		MonkeyRunner.sleep(4.0)

		print("TOUCH|{'x':173,'y':821,'type':'downAndUp',}")
		device.touch(173,821,MonkeyDevice.DOWN_AND_UP)
		MonkeyRunner.sleep(4.0)

		print("TOUCH|{'x':61,'y':1149,'type':'downAndUp',}")
		device.touch(61,1149,MonkeyDevice.DOWN_AND_UP)
		MonkeyRunner.sleep(4.0)

		print("WAIT|{'seconds':5.0,}")
		MonkeyRunner.sleep(5.0)
		print("TAKE SNAPSHOT")
		result = device.takeSnapshot()
		print("Writes the screenshot to a file")
		result.writeToFile(dir_picture+'/screenshot_'+str(index)+'_1.png','png')

		print("TOUCH|{'x':165,'y':1245,'type':'downAndUp',}")
		device.touch(165,1245,MonkeyDevice.DOWN_AND_UP)
		MonkeyRunner.sleep(4.0)

		print("TOUCH|{'x':618,'y':205,'type':'downAndUp',}")
		device.touch(618,205,MonkeyDevice.DOWN_AND_UP)
		MonkeyRunner.sleep(4.0)

		print("TOUCH|{'x':144,'y':768,'type':'downAndUp',}")
		device.touch(144,768,MonkeyDevice.DOWN_AND_UP)
		MonkeyRunner.sleep(4.0)

		print("TOUCH|{'x':74,'y':1141,'type':'downAndUp',}")
		device.touch(74,1141,MonkeyDevice.DOWN_AND_UP)
		MonkeyRunner.sleep(4.0)

		print("WAIT|{'seconds':5.0,}")
		MonkeyRunner.sleep(5.0)
		print("TAKE SNAPSHOT")
		result = device.takeSnapshot()
		print("Writes the screenshot to a file")
		result.writeToFile(dir_picture+'/screenshot_'+str(index)+'_2.png','png')

		print("TOUCH|{'x':160,'y':1229,'type':'downAndUp',}")
		device.touch(160,1229,MonkeyDevice.DOWN_AND_UP)
		MonkeyRunner.sleep(4.0)

		print("TOUCH|{'x':664,'y':186,'type':'downAndUp',}")
		device.touch(664,186,MonkeyDevice.DOWN_AND_UP)
		MonkeyRunner.sleep(4.0)

		print("TOUCH|{'x':125,'y':685,'type':'downAndUp',}")
		device.touch(125,685,MonkeyDevice.DOWN_AND_UP)
		MonkeyRunner.sleep(4.0)

		print("TOUCH|{'x':88,'y':1133,'type':'downAndUp',}")
		device.touch(88,1133,MonkeyDevice.DOWN_AND_UP)
		MonkeyRunner.sleep(4.0)

		print("WAIT|{'seconds':5.0,}")
		MonkeyRunner.sleep(5.0)
		print("TAKE SNAPSHOT")
		result = device.takeSnapshot()
		print("Writes the screenshot to a file")
		result.writeToFile(dir_picture+'/screenshot_'+str(index)+'_3.png','png')

		print("TOUCH|{'x':170,'y':1245,'type':'downAndUp',}")
		device.touch(170,1245,MonkeyDevice.DOWN_AND_UP)
		MonkeyRunner.sleep(4.0)

		print("TOUCH|{'x':170,'y':1245,'type':'downAndUp',}")
		device.touch(170,1245,MonkeyDevice.DOWN_AND_UP)
		MonkeyRunner.sleep(4.0)

		print("END LOOP")

	print("END BACK TO DESKTOP")
	device.shell('am force-stop gogolook.callgogolook2')
	MonkeyRunner.sleep(4.0)

	print("end monkey runner.")

print("get device name")
device_name = getDevice()

print("get dir of screenshot")
dir_picture = getPath()

print("Connects to the current device, returning a MonkeyDevice object")
device = MonkeyRunner.waitForConnection(5,device_name)

if not device:
	print("device connect...fail")
	sys.exit(1)
else:
	deviceModel = device.getProperty('build.model')
	print("device connect...success")
	startSteps()
	if not deviceModel in ['HTC One_M8','HTC Desire 700 dual sim']:
		device.shell("stop")
	sys.exit(0)

